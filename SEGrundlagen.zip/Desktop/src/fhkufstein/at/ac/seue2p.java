package fhkufstein.at.ac;

public class seue2p {

    public static void main(String[] args) {

        String schule= "FH Kufstein";
        System.out.println(schule);

    }
}
